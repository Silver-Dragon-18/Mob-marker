#pragma once
#include <string>
#include <vector>
#include <random>
#include <cstdint>

struct MobEntry {
    std::string id;          // e.g., "minecraft:creeper"
    std::string displayName; // e.g., "Creeper"
    std::string iconPath;    // e.g., "assets/mob_heads/creeper.png"
    uint32_t textureId = 0;  // OpenGL texture handle for mob head
    bool enabled = false;
    float color[4] = {0.0f, 0.95f, 1.0f, 0.85f}; // RGBA
};

class MobRegistry {
public:
    static MobRegistry& instance() {
        static MobRegistry reg;
        return reg;
    }

    MobRegistry() {
        // Full list of overworld, nether, and end mobs
        mobs = {
            {"minecraft:zombie",          "Zombie",          "zombie.png"},
            {"minecraft:skeleton",        "Skeleton",        "skeleton.png"},
            {"minecraft:creeper",         "Creeper",         "creeper.png"},
            {"minecraft:spider",          "Spider",          "spider.png"},
            {"minecraft:enderman",        "Enderman",        "enderman.png"},
            {"minecraft:witch",           "Witch",           "witch.png"},
            {"minecraft:slime",           "Slime",           "slime.png"},
            {"minecraft:drowned",         "Drowned",         "drowned.png"},
            {"minecraft:husk",            "Husk",            "husk.png"},
            {"minecraft:stray",           "Stray",           "stray.png"},
            {"minecraft:phantom",         "Phantom",         "phantom.png"},
            {"minecraft:pillager",        "Pillager",        "pillager.png"},
            {"minecraft:vindicator",      "Vindicator",      "vindicator.png"},
            {"minecraft:ravager",         "Ravager",         "ravager.png"},
            {"minecraft:warden",          "Warden",          "warden.png"},
            {"minecraft:blaze",           "Blaze",           "blaze.png"},
            {"minecraft:ghast",           "Ghast",           "ghast.png"},
            {"minecraft:piglin",          "Piglin",          "piglin.png"},
            {"minecraft:hoglin",          "Hoglin",          "hoglin.png"},
            {"minecraft:wither_skeleton", "Wither Skeleton", "wither_skeleton.png"},
            {"minecraft:magma_cube",      "Magma Cube",      "magma_cube.png"},
            {"minecraft:shulker",         "Shulker",         "shulker.png"},
            {"minecraft:iron_golem",      "Iron Golem",      "iron_golem.png"},
            {"minecraft:axolotl",         "Axolotl",         "axolotl.png"},
            {"minecraft:wolf",            "Wolf",            "wolf.png"}
        };

        // Initialize every switch with a distinct random color
        for (auto& mob : mobs) {
            randomizeColor(mob);
        }
    }

    // Generates a bright, high-contrast neon/tactical color whenever toggled ON
    void randomizeColor(MobEntry& mob) {
        static std::random_device rd;
        static std::mt19937 gen(rd());
        std::uniform_real_distribution<float> hueDist(0.0f, 1.0f);

        float h = hueDist(gen);
        float s = 0.85f; // High saturation so hologram & switch look sharp
        float v = 1.0f;

        // HSV to RGB conversion
        int i = static_cast<int>(h * 6.0f);
        float f = h * 6.0f - i;
        float p = v * (1.0f - s);
        float q = v * (1.0f - f * s);
        float t = v * (1.0f - (1.0f - f) * s);

        switch (i % 6) {
            case 0: mob.color[0] = v; mob.color[1] = t; mob.color[2] = p; break;
            case 1: mob.color[0] = q; mob.color[1] = v; mob.color[2] = p; break;
            case 2: mob.color[0] = p; mob.color[1] = v; mob.color[2] = t; break;
            case 3: mob.color[0] = p; mob.color[1] = q; mob.color[2] = v; break;
            case 4: mob.color[0] = t; mob.color[1] = p; mob.color[2] = v; break;
            case 5: mob.color[0] = v; mob.color[1] = p; mob.color[2] = q; break;
        }
        mob.color[3] = 0.90f;
    }

    std::vector<MobEntry>& getMobs() { return mobs; }

private:
    std::vector<MobEntry> mobs;
};