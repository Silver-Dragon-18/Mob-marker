#include <ll/api/mod/NativeMod.h>
#include <ll/api/mod/RegisterHelper.h>
#include <ll/api/memory/Hook.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <jni.h>

#include "MobRegistry.hpp"
#include "HologramRenderer.hpp"
#include "ScanOverlay.hpp"

// JNI hook called when the user taps the Gear icon next to this mod in LeviLauncher
extern "C" JNIEXPORT void JNICALL
Java_com_levilauncher_mod_EndfieldMobScanner_openSettings(JNIEnv*, jclass) {
    ScanOverlay::openLeviSettingsMenu();
}

// Hook eglSwapBuffers to draw the Scan button, Gear settings modal, and 3D Hologram Spawn Marks
using EglSwapBuffersFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
static EglSwapBuffersFn origEglSwapBuffers = nullptr;

EGLBoolean hookedEglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    // Note: Bind your ImGui OpenGL ES3 context on first frame, then render:
    float dt = ImGui::GetIO().DeltaTime;
    float screenW = ImGui::GetIO().DisplaySize.x;
    float screenH = ImGui::GetIO().DisplaySize.y;

    // Fetch current player coordinates & camera ViewProjection matrix from LevelRenderer
    float playerX = 0.0f, playerY = 64.0f, playerZ = 0.0f;
    float viewProj[16] = {
        1,0,0,0,
        0,1,0,0,
        0,0,1,0,
        0,0,0,1
    };

    HologramRenderer::instance().updateAndRender(dt, viewProj, screenW, screenH);
    ScanOverlay::renderHUDAndMenus(playerX, playerY, playerZ);

    return origEglSwapBuffers(dpy, surface);
}

class EndfieldMobScanner {
public:
    static EndfieldMobScanner& instance() {
        static EndfieldMobScanner inst;
        return inst;
    }

    EndfieldMobScanner() : mSelf(*ll::mod::NativeMod::current()) {}

    bool load() {
        getSelf().getLogger().info("EndfieldMobScanner loaded!");
        return true;
    }

    bool enable() {
        // Hook eglSwapBuffers via Preloader/Dobby symbol resolver
        void* swapAddr = reinterpret_cast<void*>(eglGetProcAddress("eglSwapBuffers"));
        if (swapAddr) {
            ll::memory::hook(swapAddr, reinterpret_cast<void*>(hookedEglSwapBuffers), reinterpret_cast<void**>(&origEglSwapBuffers));
        }
        getSelf().getLogger().info("EndfieldMobScanner enabled!");
        return true;
    }

    bool disable() { return true; }
    bool unload()  { return true; }

private:
    ll::mod::NativeMod& mSelf;
};

PL_REGISTER_MOD(EndfieldMobScanner, EndfieldMobScanner::instance())