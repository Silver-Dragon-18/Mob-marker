#pragma once
#include "MobRegistry.hpp"
#include <imgui.h>
#include <cmath>
#include <vector>

struct SpawnMark {
    std::string mobId;
    float worldX, worldY, worldZ;
    float width, height;     // Hitbox proportions for fake mob silhouette
    float alphaFade;         // Fades out smoothly after scan wave passes
};

class HologramRenderer {
public:
    static HologramRenderer& instance() {
        static HologramRenderer inst;
        return inst;
    }

    void triggerScan(float playerX, float playerY, float playerZ) {
        scanActive = true;
        scanTimer = 0.0f;
        originX = playerX;
        originY = playerY;
        originZ = playerZ;
        activeMarks.clear();
    }

    void addDetectedSpawnMark(const SpawnMark& mark) {
        activeMarks.push_back(mark);
    }

    void updateAndRender(float deltaTime, const float viewProjMatrix[16], float screenW, float screenH) {
        ImDrawList* drawList = ImGui::GetBackgroundDrawList();

        // 1. Render Arknights: Endfield Expanding Tactical Scan Wave
        if (scanActive) {
            scanTimer += deltaTime;
            float maxDuration = 3.5f;
            if (scanTimer >= maxDuration) {
                scanActive = false;
            } else {
                float progress = scanTimer / maxDuration;
                float currentRadius = progress * 48.0f; // 48-block scan radius
                renderEndfieldWave(drawList, viewProjMatrix, screenW, screenH, currentRadius, 1.0f - progress);
            }
        }

        // 2. Render Hologram Mob Silhouettes & Spawn Marks
        auto& mobs = MobRegistry::instance().getMobs();
        for (auto it = activeMarks.begin(); it != activeMarks.end();) {
            it->alphaFade -= deltaTime * 0.12f; // Hologram persists ~8 seconds
            if (it->alphaFade <= 0.0f) {
                it = activeMarks.erase(it);
                continue;
            }

            // Find matching mob entry & its current random color
            const MobEntry* matchedMob = nullptr;
            for (const auto& m : mobs) {
                if (m.enabled && m.id == it->mobId) {
                    matchedMob = &m;
                    break;
                }
            }

            if (matchedMob) {
                renderFakeHologramMob(drawList, *it, *matchedMob, viewProjMatrix, screenW, screenH);
            }
            ++it;
        }
    }

private:
    bool scanActive = false;
    float scanTimer = 0.0f;
    float originX = 0.0f, originY = 0.0f, originZ = 0.0f;
    std::vector<SpawnMark> activeMarks;

    bool worldToScreen(float wx, float wy, float wz, const float m[16], float sw, float sh, ImVec2& out) {
        float cx = wx * m[0] + wy * m[4] + wz * m[8]  + m[12];
        float cy = wx * m[1] + wy * m[5] + wz * m[9]  + m[13];
        float cw = wx * m[3] + wy * m[7] + wz * m[11] + m[15];
        if (cw < 0.01f) return false;
        float ndcX = cx / cw;
        float ndcY = cy / cw;
        out.x = (ndcX + 1.0f) * 0.5f * sw;
        out.y = (1.0f - ndcY) * 0.5f * sh;
        return true;
    }

    // Endfield-style segmented hexagonal/circular pulse ring + grid sweep
    void renderEndfieldWave(ImDrawList* dl, const float m[16], float sw, float sh, float radius, float alpha) {
        const int segments = 64;
        ImU32 primaryCol = IM_COL32(255, 210, 40, static_cast<int>(alpha * 220)); // Endfield tactical yellow-amber
        ImU32 secondaryCol = IM_COL32(0, 240, 255, static_cast<int>(alpha * 140)); // Cyan sub-ring

        for (int i = 0; i < segments; ++i) {
            float a1 = (i / (float)segments) * 6.283185f;
            float a2 = ((i + 1) / (float)segments) * 6.283185f;

            ImVec2 p1, p2, inner1, inner2;
            bool v1 = worldToScreen(originX + cosf(a1) * radius, originY + 0.15f, originZ + sinf(a1) * radius, m, sw, sh, p1);
            bool v2 = worldToScreen(originX + cosf(a2) * radius, originY + 0.15f, originZ + sinf(a2) * radius, m, sw, sh, p2);

            if (v1 && v2) {
                dl->AddLine(p1, p2, primaryCol, 2.5f);
                // Trailing inner echo ring
                if (radius > 2.5f &&
                    worldToScreen(originX + cosf(a1) * (radius - 2.0f), originY + 0.15f, originZ + sinf(a1) * (radius - 2.0f), m, sw, sh, inner1) &&
                    worldToScreen(originX + cosf(a2) * (radius - 2.0f), originY + 0.15f, originZ + sinf(a2) * (radius - 2.0f), m, sw, sh, inner2)) {
                    dl->AddLine(inner1, inner2, secondaryCol, 1.2f);
                }
            }
        }
    }

    // Renders a translucent "fake" holographic mob silhouette + spawn mark beacon
    void renderFakeHologramMob(ImDrawList* dl, const SpawnMark& mark, const MobEntry& mob, const float m[16], float sw, float sh) {
        ImVec2 feet, head;
        if (!worldToScreen(mark.worldX, mark.worldY, mark.worldZ, m, sw, sh, feet)) return;
        if (!worldToScreen(mark.worldX, mark.worldY + mark.height, mark.worldZ, m, sw, sh, head)) return;

        float pixelH = fabsf(feet.y - head.y);
        float pixelW = pixelH * (mark.width / mark.height);
        float a = mark.alphaFade;

        ImU32 holoLine = ImGui::ColorConvertFloat4ToU32(ImVec4(mob.color[0], mob.color[1], mob.color[2], a * 0.95f));
        ImU32 holoFill = ImGui::ColorConvertFloat4ToU32(ImVec4(mob.color[0], mob.color[1], mob.color[2], a * 0.22f));

        // 1. Fake Mob Silhouette (Head + Torso + Legs wireframe hologram)
        float headSize = pixelH * 0.26f;
        ImVec2 headMin(head.x - headSize * 0.5f, head.y);
        ImVec2 headMax(head.x + headSize * 0.5f, head.y + headSize);
        dl->AddRectFilled(headMin, headMax, holoFill, 2.0f);
        dl->AddRect(headMin, headMax, holoLine, 2.0f, 0, 1.8f);

        ImVec2 bodyMin(head.x - pixelW * 0.45f, headMax.y + 2.0f);
        ImVec2 bodyMax(head.x + pixelW * 0.45f, feet.y);
        dl->AddRectFilled(bodyMin, bodyMax, holoFill, 2.0f);
        dl->AddRect(bodyMin, bodyMax, holoLine, 2.0f, 0, 1.8f);

        // 2. Holographic Scanlines scrolling vertically inside the fake mob
        float scanOffset = fmodf(ImGui::GetTime() * 40.0f, pixelH);
        for (float y = head.y + fmodf(scanOffset, 6.0f); y < feet.y; y += 6.0f) {
            dl->AddLine(ImVec2(bodyMin.x, y), ImVec2(bodyMax.x, y), holoLine, 1.0f);
        }

        // 3. Ground Spawn Mark Ring & Label
        dl->AddCircle(feet, pixelW * 0.75f, holoLine, 24, 2.0f);
        std::string label = "[SPAWN MARK] " + mob.displayName;
        dl->AddText(ImVec2(head.x - 45.0f, head.y - 18.0f), holoLine, label.c_str());
    }
};