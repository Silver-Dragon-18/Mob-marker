#pragma once
#include "MobRegistry.hpp"
#include "HologramRenderer.hpp"
#include <imgui.h>

class ScanOverlay {
public:
    static bool showSettingsModal;

    // Called from LeviLauncher's Gear icon callback
    static void openLeviSettingsMenu() {
        showSettingsModal = true;
    }

    // Custom animated toggle switch colored with the mob's random color
    static bool ColoredMobToggle(const char* strId, bool* v, MobEntry& mob) {
        ImVec2 p = ImGui::GetCursorScreenPos();
        ImDrawList* drawList = ImGui::GetWindowDrawList();

        float height = 24.0f;
        float width = 46.0f;
        float radius = height * 0.50f;

        ImGui::InvisibleButton(strId, ImVec2(width, height));
        bool clicked = ImGui::IsItemClicked();
        if (clicked) {
            *v = !(*v);
            if (*v) {
                // Turned OFF -> ON: Assign a brand-new random color!
                MobRegistry::instance().randomizeColor(mob);
            }
        }

        ImU32 bgCol = *v
            ? ImGui::ColorConvertFloat4ToU32(ImVec4(mob.color[0], mob.color[1], mob.color[2], 1.0f))
            : IM_COL32(65, 68, 75, 255);

        drawList->AddRectFilled(p, ImVec2(p.x + width, p.y + height), bgCol, radius);
        float knobX = *v ? (p.x + width - radius) : (p.x + radius);
        drawList->AddCircleFilled(ImVec2(knobX, p.y + radius), radius - 3.0f, IM_COL32(255, 255, 255, 255));

        return clicked;
    }

    static void renderHUDAndMenus(float playerX, float playerY, float playerZ) {
        // 1. Floating Tactical Scan Button (Arknights: Endfield style)
        ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x - 110.0f, ImGui::GetIO().DisplaySize.y * 0.45f), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowBgAlpha(0.0f);
        ImGui::Begin("##EndfieldScanBtnWin", nullptr,
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoScrollbar);

        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.12f, 0.13f, 0.16f, 0.85f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.82f, 0.15f, 0.90f));
        ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(1.0f, 0.82f, 0.15f, 1.0f));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 2.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 32.0f);

        if (ImGui::Button("SCAN", ImVec2(68.0f, 68.0f))) {
            HologramRenderer::instance().triggerScan(playerX, playerY, playerZ);
        }

        ImGui::PopStyleVar(2);
        ImGui::PopStyleColor(3);
        ImGui::End();

        // 2. LeviLauncher Gear Settings Menu (All Mob Heads + Random-Color Toggle Switches)
        if (showSettingsModal) {
            ImGui::SetNextWindowSize(ImVec2(420.0f, 520.0f), ImGuiCond_FirstUseEver);
            if (ImGui::Begin("Mob Spawn Scanner Settings", &showSettingsModal)) {
                ImGui::TextWrapped("Toggle a mob to scan its spawn marks. Turning a switch OFF and ON assigns a new random hologram color.");
                ImGui::Separator();

                auto& mobs = MobRegistry::instance().getMobs();
                for (size_t i = 0; i < mobs.size(); ++i) {
                    auto& mob = mobs[i];
                    ImGui::PushID(static_cast<int>(i));

                    // Mob Head Icon (32x32)
                    if (mob.textureId != 0) {
                        ImGui::Image((ImTextureID)(intptr_t)mob.textureId, ImVec2(32.0f, 32.0f));
                    } else {
                        // Fallback colored head preview box if PNG isn't loaded yet
                        ImVec4 previewCol(mob.color[0], mob.color[1], mob.color[2], 1.0f);
                        ImGui::ColorButton("##headPreview", previewCol, ImGuiColorEditFlags_NoTooltip, ImVec2(32.0f, 32.0f));
                    }

                    ImGui::SameLine(48.0f);
                    ImGui::AlignTextToFramePadding();
                    ImGui::Text("%s", mob.displayName.c_str());

                    // Right-aligned Random-Color Toggle Switch
                    ImGui::SameLine(ImGui::GetWindowWidth() - 75.0f);
                    ColoredMobToggle("##mobSwitch", &mob.enabled, mob);

                    ImGui::PopID();
                }
            }
            ImGui::End();
        }
    }
};

inline bool ScanOverlay::showSettingsModal = false;